package org.example.chessanalyzer;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle state) { super.onCreate(state); WebView view = new WebView(this); view.getSettings().setJavaScriptEnabled(true); view.getSettings().setAllowFileAccess(false); view.getSettings().setAllowContentAccess(false); setContentView(view); view.loadUrl("file:///android_asset/index.html"); }
}
