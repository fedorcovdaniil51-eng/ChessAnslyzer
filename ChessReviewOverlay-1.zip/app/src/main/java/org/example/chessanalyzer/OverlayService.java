package org.example.chessanalyzer;
import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.view.*;
import android.widget.TextView;

public class OverlayService extends Service {
 private WindowManager wm;private TextView bubble;private WindowManager.LayoutParams params;
 private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 @Override public IBinder onBind(Intent i){return null;}
 @Override public int onStartCommand(Intent i,int flags,int id){
  if(i!=null&&"stop".equals(i.getAction())){stopSelf();return START_NOT_STICKY;}
  NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("review","Chess Review",NotificationManager.IMPORTANCE_LOW));
  PendingIntent open=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  PendingIntent stop=PendingIntent.getService(this,2,new Intent(this,OverlayService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  startForeground(1,new Notification.Builder(this,"review").setContentTitle("Chess Review").setContentText("Плавающая кнопка разбора").setSmallIcon(android.R.drawable.ic_menu_view).setContentIntent(open).addAction(new Notification.Action.Builder(null,"Выключить",stop).build()).setOngoing(true).build());
  if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}if(bubble!=null)return START_NOT_STICKY;
  wm=(WindowManager)getSystemService(WINDOW_SERVICE);bubble=new TextView(this);bubble.setText("♟");bubble.setTextSize(26);bubble.setGravity(Gravity.CENTER);bubble.setTextColor(Color.WHITE);bubble.setContentDescription("Открыть разбор; удерживать для выключения");GradientDrawable bg=new GradientDrawable();bg.setColor(0xff286c48);bg.setCornerRadius(dp(28));bg.setStroke(dp(2),0xff90e3b6);bubble.setBackground(bg);
  params=new WindowManager.LayoutParams(dp(54),dp(54),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.LEFT;params.x=dp(12);params.y=dp(160);
  bubble.setOnTouchListener(new View.OnTouchListener(){float x,y;int sx,sy;long time;boolean moved;
   public boolean onTouch(View v,android.view.MotionEvent e){switch(e.getActionMasked()){
    case MotionEvent.ACTION_DOWN:x=e.getRawX();y=e.getRawY();sx=params.x;sy=params.y;time=android.os.SystemClock.elapsedRealtime();moved=false;return true;
    case MotionEvent.ACTION_MOVE:float dx=e.getRawX()-x,dy=e.getRawY()-y;if(Math.abs(dx)>dp(6)||Math.abs(dy)>dp(6))moved=true;if(moved){params.x=Math.max(0,sx+(int)dx);params.y=Math.max(0,sy+(int)dy);try{wm.updateViewLayout(bubble,params);}catch(Exception ignored){}}return true;
    case MotionEvent.ACTION_UP:if(!moved){if(android.os.SystemClock.elapsedRealtime()-time>600)stopSelf();else{Intent a=new Intent(OverlayService.this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);try{startActivity(a);}catch(Exception ignored){}}}return true;
    case MotionEvent.ACTION_CANCEL:return true;default:return false;}}
  });
  try{wm.addView(bubble,params);}catch(Exception e){bubble=null;stopSelf();}return START_NOT_STICKY;
 }
 @Override public void onDestroy(){if(bubble!=null&&wm!=null){try{wm.removeView(bubble);}catch(Exception ignored){}}bubble=null;super.onDestroy();}
}
