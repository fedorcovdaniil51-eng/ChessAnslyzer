package org.example.chessanalyzer;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.webkit.WebView;
import android.widget.*;

public class MainActivity extends Activity {
 private boolean pending=false;
 private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 @Override public void onCreate(Bundle b){super.onCreate(b);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(20,26,24));root.setPadding(dp(8),dp(8),dp(8),dp(8));
  LinearLayout bar=new LinearLayout(this);Button start=new Button(this);start.setText("Плавающая кнопка");Button stop=new Button(this);stop.setText("Выключить");bar.addView(start,new LinearLayout.LayoutParams(0,-2,1));bar.addView(stop,new LinearLayout.LayoutParams(0,-2,1));root.addView(bar);
  WebView web=new WebView(this);web.setBackgroundColor(Color.rgb(20,26,24));web.getSettings().setJavaScriptEnabled(true);web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);web.loadUrl("file:///android_asset/index.html");root.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
  start.setOnClickListener(v->{if(Settings.canDrawOverlays(this)){launchOverlay();}else{pending=true;try{startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));}catch(Exception e){pending=false;Toast.makeText(this,"Разрешение недоступно",Toast.LENGTH_LONG).show();}}});
  stop.setOnClickListener(v->stopService(new Intent(this,OverlayService.class)));
 }
 @Override protected void onResume(){super.onResume();if(pending&&Settings.canDrawOverlays(this)){pending=false;launchOverlay();}}
 private void launchOverlay(){try{startForegroundService(new Intent(this,OverlayService.class));Toast.makeText(this,"Кнопка включена",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Не удалось включить кнопку: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
}
